import React, { useState } from "react";

const sendTelegramAlert = async () => {
  const token = process.env.REACT_APP_TELEGRAM_BOT;
  const chatId = process.env.REACT_APP_TELEGRAM_CHAT_ID;
  const message = "✅ BTC Trade Setup is Ready to Execute! 📈 All checklist items confirmed.";

  await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      chat_id: chatId,
      text: message,
    }),
  });
};

const App = () => {
  const [trade, setTrade] = useState({
    entryZone: false,
    choch: false,
    confirmationCandle: false,
    multiTFConfirm: false,
    riskSet: false,
    slSet: false,
    tpSet: false,
    tradeReady: false,
  });

  const handleChange = (field) => {
    setTrade((prev) => ({ ...prev, [field]: !prev[field] }));
  };

  const checkAllReady = () => {
    const keys = Object.keys(trade).filter(k => k !== "tradeReady");
    const ready = keys.every(k => trade[k]);
    setTrade((prev) => ({ ...prev, tradeReady: ready }));
    if (ready) sendTelegramAlert();
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>BTC Trade Setup Checklist</h2>
      {Object.entries(trade).map(([key, value]) => {
        if (key === "tradeReady") return null;
        return (
          <div key={key}>
            <label>
              <input type="checkbox" checked={value} onChange={() => handleChange(key)} />
              {key}
            </label>
          </div>
        );
      })}
      <button onClick={checkAllReady} style={{ marginTop: 20 }}>✅ Validate Trade Readiness</button>
      <div style={{ marginTop: 10, fontWeight: "bold" }}>
        {trade.tradeReady ? "✅ Trade Ready!" : "⚠️ Incomplete Setup"}
      </div>
    </div>
  );
};

export default App;
